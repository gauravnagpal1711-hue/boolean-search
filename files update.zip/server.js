const express = require('express');
const path = require('path');

const app = express();
app.use(express.json({ limit: '10mb' }));
app.use(express.static(path.join(__dirname)));

function extractJSON(text) {
  // Remove markdown fences
  let txt = text.replace(/```json\s*/gi, '').replace(/```/g, '');
  // Fix smart quotes
  txt = txt.replace(/[\u2018\u2019]/g, "'").replace(/[\u201C\u201D]/g, '"');
  // Find outermost { }
  const start = txt.indexOf('{');
  const end = txt.lastIndexOf('}');
  if (start < 0 || end <= start) throw new Error('No JSON found in response');
  const jsonStr = txt.slice(start, end + 1);
  try {
    return JSON.parse(jsonStr);
  } catch (e) {
    // Try sanitizing: remove control characters
    const sanitized = jsonStr.replace(/[\x00-\x1F\x7F]/g, ' ');
    return JSON.parse(sanitized);
  }
}

// Proxy endpoint — keeps API key server-side, never exposed to browser
app.post('/api/claude', async (req, res) => {
  try {
    const apiKey = process.env.ANTHROPIC_API_KEY;
    if (!apiKey) {
      return res.status(500).json({ error: { message: 'API key not configured on server.' } });
    }
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'x-api-key': apiKey,
        'content-type': 'application/json',
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify(req.body)
    });
    const data = await response.json();
    if (!response.ok) return res.status(response.status).json(data);

    // If this is a generate request, extract and validate JSON on server side
    const isGenerate = req.body.max_tokens >= 3000;
    if (isGenerate) {
      try {
        const rawText = data.content.filter(b => b.type === 'text').map(b => b.text).join('');
        const parsed = extractJSON(rawText);
        return res.json({ success: true, result: parsed });
      } catch (parseErr) {
        return res.status(500).json({ error: { message: 'JSON parse error on server: ' + parseErr.message } });
      }
    }

    res.json(data);
  } catch (err) {
    res.status(500).json({ error: { message: err.message } });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
